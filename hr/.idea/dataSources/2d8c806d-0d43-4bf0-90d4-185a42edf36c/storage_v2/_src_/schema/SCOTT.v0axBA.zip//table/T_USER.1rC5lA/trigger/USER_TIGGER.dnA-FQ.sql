create trigger USER_TIGGER
  before insert
  on T_USER
  for each row
  BEGIN
SELECT user_seq.nextval INTO :new.u_id FROM dual;
end;
/

