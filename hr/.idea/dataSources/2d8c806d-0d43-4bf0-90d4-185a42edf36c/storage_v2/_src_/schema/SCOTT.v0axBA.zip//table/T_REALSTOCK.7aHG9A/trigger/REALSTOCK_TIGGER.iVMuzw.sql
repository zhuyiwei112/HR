create trigger REALSTOCK_TIGGER
  before insert
  on T_REALSTOCK
  for each row
  BEGIN
SELECT orders_seq.nextval INTO :NEW.rs_id FROM dual;
end;
/

