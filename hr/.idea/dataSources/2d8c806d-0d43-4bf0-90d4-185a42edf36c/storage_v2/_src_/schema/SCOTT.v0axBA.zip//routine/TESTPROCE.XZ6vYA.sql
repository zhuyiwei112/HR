create procedure testProce
  as 
  begin 
    dbms_output.put_line('hi');
  end;
/

