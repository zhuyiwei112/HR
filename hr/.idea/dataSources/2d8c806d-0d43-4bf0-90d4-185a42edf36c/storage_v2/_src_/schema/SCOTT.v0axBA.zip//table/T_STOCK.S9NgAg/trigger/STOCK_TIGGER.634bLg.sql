create trigger STOCK_TIGGER
  before insert
  on T_STOCK
  for each row
  BEGIN
SELECT stock_seq.nextval INTO :NEW.s_id FROM dual;
end;
/

