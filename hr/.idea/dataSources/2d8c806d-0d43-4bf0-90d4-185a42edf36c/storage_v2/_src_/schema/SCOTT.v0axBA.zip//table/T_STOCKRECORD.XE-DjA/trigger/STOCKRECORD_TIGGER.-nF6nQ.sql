create trigger STOCKRECORD_TIGGER
  before insert
  on T_STOCKRECORD
  for each row
  BEGIN
SELECT stockrecord_seq.nextval INTO :NEW.sr_id FROM dual;
end;
/

