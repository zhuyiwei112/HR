create trigger ORDERS_TIGGER
  before insert
  on T_ORDERS
  for each row
  BEGIN
SELECT orders_seq.nextval INTO :NEW.o_id FROM dual;
end;
/

