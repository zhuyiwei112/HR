create trigger COMMENT1_TIGGER
  before insert
  on T_COMMENT
  for each row
  BEGIN
SELECT comment1_seq.nextval INTO :NEW.c_id FROM dual;
end;
/

