create trigger BUYCAR_TIGGER
  before insert
  on T_BUYCAR
  for each row
  BEGIN
SELECT buycar_seq.nextval INTO :NEW.bc_id FROM dual;
end;
/

