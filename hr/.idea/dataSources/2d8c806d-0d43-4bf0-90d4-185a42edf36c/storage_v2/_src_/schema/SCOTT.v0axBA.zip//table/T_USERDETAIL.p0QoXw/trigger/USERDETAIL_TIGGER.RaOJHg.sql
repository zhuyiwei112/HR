create trigger USERDETAIL_TIGGER
  before insert
  on T_USERDETAIL
  for each row
  BEGIN
SELECT userdetail_seq.nextval INTO :NEW.ud_id FROM dual;
end;
/

