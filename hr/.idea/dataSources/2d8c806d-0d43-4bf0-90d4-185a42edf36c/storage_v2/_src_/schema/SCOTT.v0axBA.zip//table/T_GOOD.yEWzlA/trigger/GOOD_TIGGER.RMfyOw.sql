create trigger GOOD_TIGGER
  before insert
  on T_GOOD
  for each row
  BEGIN
SELECT GOOD_seq.nextval INTO :NEW.g_id FROM dual;
end;
/

