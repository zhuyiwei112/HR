create trigger TR_EMPLOYEE
  before insert or update or delete
  on EMPLOYEE
  BEGIN
 IF((TO_CHAR(sysdate,'DAY') in('星期六','星期日')) OR ((TO_CHAR(sysdate,'HH24:MI') NOT BETWEEN '09:00' AND '18:00')))
	THEN raise_application_error(-20022,'不在工作时间') ;
 END IF;END;
/

