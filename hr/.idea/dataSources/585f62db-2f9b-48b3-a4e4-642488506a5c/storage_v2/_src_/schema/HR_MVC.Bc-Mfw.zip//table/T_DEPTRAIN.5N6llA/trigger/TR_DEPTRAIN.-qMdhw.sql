create trigger TR_DEPTRAIN
  before insert
  on T_DEPTRAIN
  for each row
  begin       
select DEPTRAIN_SEQ.nextval into:new.DT_ID from dual;
end;
/

