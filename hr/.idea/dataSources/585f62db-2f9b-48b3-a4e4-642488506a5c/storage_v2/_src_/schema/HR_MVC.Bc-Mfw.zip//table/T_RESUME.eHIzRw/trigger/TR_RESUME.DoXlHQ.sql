create trigger TR_RESUME
  before insert
  on T_RESUME
  for each row
  begin       
select RESUME_SEQ.nextval into:new.R_ID from dual;   
end;
/

