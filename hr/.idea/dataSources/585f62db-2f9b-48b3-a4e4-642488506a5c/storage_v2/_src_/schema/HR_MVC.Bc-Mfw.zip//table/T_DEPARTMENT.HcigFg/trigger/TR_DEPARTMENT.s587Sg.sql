create trigger TR_DEPARTMENT
  before insert
  on T_DEPARTMENT
  for each row
  begin       
select DEPARTMENT_SEQ.nextval into:new.D_ID from dual;   
end;
/

