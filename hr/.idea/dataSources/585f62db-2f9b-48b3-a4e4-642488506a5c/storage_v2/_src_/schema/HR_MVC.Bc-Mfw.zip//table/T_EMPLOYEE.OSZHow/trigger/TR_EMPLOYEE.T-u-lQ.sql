create trigger TR_EMPLOYEE
  before insert
  on T_EMPLOYEE
  for each row
  begin       
select EMPLOYEE_SEQ.nextval into:new.E_ID from dual;   
end;
/

