create trigger TR_SALARY
  before insert
  on T_SALARY
  for each row
  begin       
select SALARY_SEQ.nextval into:new.S_ID from dual;   
end;
/

