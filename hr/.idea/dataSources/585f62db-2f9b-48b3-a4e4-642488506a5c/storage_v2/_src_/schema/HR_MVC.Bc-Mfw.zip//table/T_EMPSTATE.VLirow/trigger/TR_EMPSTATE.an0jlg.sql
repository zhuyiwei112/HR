create trigger TR_EMPSTATE
  before insert
  on T_EMPSTATE
  for each row
  begin       
select EMPSTATE_SEQ.nextval into:new.ES_ID from dual;   
end;
/

