create trigger TR_POSITION
  before insert
  on T_POSITION
  for each row
  begin       
select POSITION_SEQ.nextval into:new.P_ID from dual;   
end;
/

