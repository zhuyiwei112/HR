create trigger TR_ADSTATE
  before insert
  on T_ADSTATE
  for each row
  begin       
select ADSTATE_SEQ.nextval into:new.AS_ID from dual;   
end;
/

