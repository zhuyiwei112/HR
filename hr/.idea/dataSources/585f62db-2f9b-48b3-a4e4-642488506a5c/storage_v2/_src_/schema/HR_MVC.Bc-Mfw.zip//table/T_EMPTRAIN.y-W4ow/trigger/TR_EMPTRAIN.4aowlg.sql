create trigger TR_EMPTRAIN
  before insert
  on T_EMPTRAIN
  for each row
  begin       
select EMPTRAIN_SEQ.nextval into:new.ET_ID from dual;
end;
/

