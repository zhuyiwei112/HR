create trigger TR_RECRUIT
  before insert
  on T_RECRUIT
  for each row
  begin       
select RECRUIT_SEQ.nextval into:new.RC_ID from dual;
end;
/

