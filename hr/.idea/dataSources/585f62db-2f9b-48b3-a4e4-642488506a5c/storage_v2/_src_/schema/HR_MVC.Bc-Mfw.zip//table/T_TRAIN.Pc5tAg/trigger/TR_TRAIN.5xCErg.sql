create trigger TR_TRAIN
  before insert
  on T_TRAIN
  for each row
  begin       
select TRAIN_SEQ.nextval into:new.T_ID from dual;
end;
/

