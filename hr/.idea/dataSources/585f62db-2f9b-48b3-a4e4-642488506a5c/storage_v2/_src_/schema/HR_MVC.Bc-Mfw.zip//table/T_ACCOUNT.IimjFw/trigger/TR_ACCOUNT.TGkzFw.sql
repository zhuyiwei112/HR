create trigger TR_ACCOUNT
  before insert
  on T_ACCOUNT
  for each row
  begin       
select ACCOUNT_SEQ.nextval into:new.A_ID from dual;   
end;
/

