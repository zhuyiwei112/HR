create trigger TR_DELIVERRES
  before insert
  on T_DELIVERRES
  for each row
  begin       
select DELIVERRES_SEQ.nextval into:new.DR_ID from dual;   
end;
/

