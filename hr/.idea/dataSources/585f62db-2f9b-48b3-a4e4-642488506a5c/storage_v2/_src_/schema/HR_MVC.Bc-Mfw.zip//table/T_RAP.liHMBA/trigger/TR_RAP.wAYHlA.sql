create trigger TR_RAP
  before insert
  on T_RAP
  for each row
  begin       
select RAP_SEQ.nextval into:new.RP_ID from dual;   
end;
/

