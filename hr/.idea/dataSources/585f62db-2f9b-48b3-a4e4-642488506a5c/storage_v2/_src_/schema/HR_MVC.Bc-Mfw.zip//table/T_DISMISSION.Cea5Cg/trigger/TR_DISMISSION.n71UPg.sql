create trigger TR_DISMISSION
  before insert
  on T_DISMISSION
  for each row
  begin       
select DISMISSION_SEQ.nextval into:new.DM_ID from dual;   
end;
/

