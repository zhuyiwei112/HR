create trigger TR_ATTENDANCE
  before insert
  on T_ATTENDANCE
  for each row
  begin       
select ATTENDANCE_SEQ.nextval into:new.AD_ID from dual;   
end;
/

